package org.teamweaver.delias.commons;

import java.util.ArrayList;

import org.teamweaver.delias.actions.ActionSetImpl;

public class BrowseHistory {
	private static ArrayList<ActionSetImpl> actionSetsList;
	
	public BrowseHistory() {
		// TODO Auto-generated constructor stub
	}

}
