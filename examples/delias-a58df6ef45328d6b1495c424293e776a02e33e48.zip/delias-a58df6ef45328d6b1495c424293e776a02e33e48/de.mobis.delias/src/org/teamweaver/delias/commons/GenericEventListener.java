package org.teamweaver.delias.commons;


import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;

public class GenericEventListener extends AbstractListener implements Listener{

	
	public void handleEvent(Event event) {
		
		//System.out.println(event.button);
		//System.out.println(event.toString());
		//senseEvent(event);
	}

}
