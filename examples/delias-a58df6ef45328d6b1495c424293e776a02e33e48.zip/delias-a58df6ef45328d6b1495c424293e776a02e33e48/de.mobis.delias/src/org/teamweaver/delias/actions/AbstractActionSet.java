package org.teamweaver.delias.actions;

public abstract class AbstractActionSet implements IActionSet{

}
