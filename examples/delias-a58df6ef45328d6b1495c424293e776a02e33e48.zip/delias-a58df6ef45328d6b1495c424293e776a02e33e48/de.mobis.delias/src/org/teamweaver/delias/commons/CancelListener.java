package org.teamweaver.delias.commons;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.widgets.Event;

public interface CancelListener {
	public void cancelDetected(Event event);

}
