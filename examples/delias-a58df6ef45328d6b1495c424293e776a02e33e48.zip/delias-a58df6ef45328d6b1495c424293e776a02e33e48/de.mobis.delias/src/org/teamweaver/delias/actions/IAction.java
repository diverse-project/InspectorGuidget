package org.teamweaver.delias.actions;

public interface IAction {

}
